#include <graphics.h>
#include <conio.h>
#include <iostream>
#include <time.h>
void loading(){
	int c=11;
	initwindow(800,600,"Loading.....!");
    readimagefile("gdi2.jpg",0,0,191,189);
	int imagefil10=imagesize(0,0,191,189);
	void *buffer10=malloc(imagefil10);
    getimage(0,0,191,189,buffer10);
	setbkcolor(3);
	cleardevice();
	putimage(275,100,buffer10,COPY_PUT);
		setcolor(0);
	settextstyle(3,0,5);
	outtextxy(250,310,"GGI CO-OP");
	rectangle(195,299,550,303);
	for (int i=196;i<550;i++){
		putpixel(i,300,c);
		putpixel(i,301,c);
		putpixel(i,302,c);
		delay(20);
	}
	closegraph();	
}

void mainScreen(){

	initwindow(800,600,"AI DOZE",200,50);
	setbkcolor(15);
	cleardevice();
   
    readimagefile("background.jpg",0,0,800,600);
	int imagefil=imagesize(0,0,800,600);
	void *buffer=malloc(imagefil);
	getimage(0,0,800,600,buffer);
 	putimage(0,0,buffer,COPY_PUT); 
}

void p1(){
	
    readimagefile("player-win.jpg",0,0,251,121);
	int imagefil5=imagesize(0,0,251,121);
	void *buffer5=malloc(imagefil5);
	getimage(0,0,251,121,buffer5);
		cleardevice();
		     putimage(250,300,buffer5,COPY_PUT);
}

void p2(){
    setbkcolor(3);
    readimagefile("player2-win.jpg",0,0,173,93);
	int imagefil9=imagesize(0,0,173,93);
	void *buffer9=malloc(imagefil9);
	getimage(0,0,173,93,buffer9);
	cleardevice();
	putimage(250,250,buffer9,COPY_PUT);
}

using namespace std;	
	 main(){
		int x_m,y_m;
	loading();
A:	mainScreen();

	

		while (true){
	
	getmouseclick(WM_LBUTTONDOWN,x_m,y_m);
	if(x_m>700 && x_m<800 && y_m>450 && y_m<600){
	initwindow(800,250,"Exit",200,50);
	setbkcolor(11);
	cleardevice();
	int x_m,y_m;
   
    readimagefile("Exit-bar.jpg",0,0,800,250);
	int imagefil11=imagesize(0,0,800,250);
	void *buffer11=malloc(imagefil11);
    getimage(0,0,800,250,buffer11);
    putimage(0,0,buffer11,COPY_PUT);
		while (true){
	
	getmouseclick(WM_LBUTTONDOWN,x_m,y_m);
	if(x_m>243 && x_m<350 && y_m>70 && y_m<174){
closegraph();
	}
	if(x_m>467 && x_m<544 && y_m>89 && y_m<164){
 goto A;
	}
	}
	}


		if(x_m>173 && x_m<322 && y_m>159 && y_m<304){
			setcolor(0);
	bool robot=true;
srand(time(NULL));
	int win=-1;
	int Ground[9]={0};
	int X[1]={0};
	int player=0;
	int Cell=-1;
	int XD,YD;
	int x_m,y_m;
	
		initwindow(800,600,"1Player DOZE",200,50);
		setbkcolor(COLOR(0,0,255));
		cleardevice();
		setcolor(0);
		rectangle(100,0,300,200);
		rectangle(100,200,300,400);
		rectangle(100,400,300,600);	
		rectangle(105,5,295,195);
		rectangle(105,205,295,395);
		rectangle(105,405,295,595);
		rectangle(300,0,500,200);
		rectangle(300,200,500,400);
		rectangle(300,400,500,600);
		rectangle(305,5,495,195);
		rectangle(305,205,495,395);
		rectangle(305,405,495,595);
		rectangle(500,0,700,200);
		rectangle(500,200,700,400);
		rectangle(500,400,700,600);
		rectangle(505,5,695,195);
		rectangle(505,205,695,395);
		rectangle(505,405,695,595);
		
	while(true){
		getmouseclick(WM_LBUTTONDOWN,x_m,y_m);
	if(x_m>100 && x_m<300 && y_m>0 && y_m<200){Cell=0; XD=200;YD=100;	}	
	if(x_m>100 && x_m<300 && y_m>200 && y_m<400){Cell=1; XD=200;YD=300;	}
	if(x_m>100 && x_m<300 && y_m>400 && y_m<600){Cell=2; XD=200;YD=500;	}	
	if(x_m>300 && x_m<500 && y_m>0 && y_m<200){Cell=3; XD=400;YD=100;	}	
	if(x_m>300 && x_m<500 && y_m>200 && y_m<400){Cell=4; XD=400;YD=300;	}
	if(x_m>300 && x_m<500 && y_m>400 && y_m<600){Cell=5; XD=400;YD=500;	}
	if(x_m>500 && x_m<700 && y_m>0 && y_m<200){Cell=6; XD=600;YD=100;	}	
	if(x_m>500 && x_m<700 && y_m>200 && y_m<400){Cell=7; XD=600;YD=300;	}
	if(x_m>500 && x_m<700 && y_m>400 && y_m<600){Cell=8; XD=600;YD=500;	}
	if (Cell>=0){
				setcolor(11);
		if(player==0 && Ground[Cell]==0){
			circle(XD,YD,80);
				circle(XD,YD,70);
			player=1;
		    Ground[Cell]=1;		
		}
	int s1[9]={0};
		int number=0;
		for(int i=0;i<9;i++){
			if(Ground[i]==0){
			s1[number]=i;
			number++;	
		cout<<"\nN "<<i<<" ,";			
			}}
	
	Cell=s1[rand()%number];	
		
		   		if(player==1 && Ground[Cell]==0){
		// Ghotr
	        if(Ground[0]==1 && Ground[8]==1){Cell=4; }else{Cell=s1[rand()%number];	}
	        if(Ground[6]==1 && Ground[2]==1){Cell=4; }else{Cell=s1[rand()%number];	}
        // +
			if(Ground[3]==1 && Ground[5]==1){Cell=4; }else{Cell=s1[rand()%number];	}
	        if(Ground[1]==1 && Ground[7]==1){Cell=4; }else{Cell=s1[rand()%number];	}
	    // 2next
		 	if(Ground[0]==1 && Ground[1]==1){Cell=2; }else{Cell=s1[rand()%number];	}
	        if(Ground[1]==1 && Ground[2]==1){Cell=0; }else{Cell=s1[rand()%number];	}  
			if(Ground[3]==1 && Ground[4]==1){Cell=5; }else{Cell=s1[rand()%number];	}
	        if(Ground[4]==1 && Ground[5]==1){Cell=3; }else{Cell=s1[rand()%number];	}
	       	if(Ground[6]==1 && Ground[7]==1){Cell=8; }else{Cell=s1[rand()%number];	}
	        if(Ground[7]==1 && Ground[8]==1){Cell=6; }else{Cell=s1[rand()%number];	}
        //1+3 Row
        	if(Ground[0]==1 && Ground[6]==1){Cell=3; }else{Cell=s1[rand()%number];	}
	        if(Ground[2]==1 && Ground[8]==1){Cell=5;  }else{Cell=s1[rand()%number];	}
	    //1+3 Col
			if(Ground[0]==1 && Ground[2]==1){Cell=1; }else{Cell=s1[rand()%number];	}
	        if(Ground[6]==1 && Ground[8]==1){Cell=7;  }else{Cell=s1[rand()%number];	}
	
			setcolor(0);
	        	if(Cell==0){XD=200;	YD=100;	}
				if(Cell==1){XD=200;	YD=300;	}
				if(Cell==2){XD=200;	YD=500;	}
		    	if(Cell==3){XD=400;	YD=100;	}
				if(Cell==4){XD=400;	YD=300;	}
				if(Cell==5){XD=400;	YD=500;	}
				if(Cell==6){XD=600;	YD=100;	}
				if(Cell==7){XD=600;	YD=300;	}
				if(Cell==8){XD=600;	YD=500;	}	
		line(XD-70,YD-70,XD+70,YD+70);
	    line(XD+70,YD-70,XD-70,YD+70); 
			player=0;
		    Ground[Cell]=2;
	} 
	
				
			Cell=-1;
		
				}
	   
		
	
	//player 1   +8
	if(Ground[0]==1 && Ground[1]==1 && Ground[2]==1){win=1;delay(1000);break;	}
	if(Ground[3]==1 && Ground[4]==1 && Ground[5]==1){win=1;delay(1000);break;	}
	if(Ground[6]==1 && Ground[7]==1 && Ground[8]==1){win=1;delay(1000);break;	}
	if(Ground[0]==1 && Ground[3]==1 && Ground[6]==1){win=1;delay(1000);break;	}
	if(Ground[1]==1 && Ground[4]==1 && Ground[7]==1){win=1;delay(1000);break;	}
	if(Ground[2]==1 && Ground[5]==1 && Ground[8]==1){win=1;delay(1000);break;	}
	if(Ground[2]==1 && Ground[4]==1 && Ground[6]==1){win=1;delay(1000);break;	}
	if(Ground[0]==1 && Ground[4]==1 && Ground[8]==1){win=1;delay(1000);break;	}

	//Machine    +8
	if(Ground[0]==2 && Ground[1]==2 && Ground[2]==2){win=2;delay(1000);break;	}
	if(Ground[3]==2 && Ground[4]==2 && Ground[5]==2){win=2;delay(1000);break;   	}
	if(Ground[6]==2 && Ground[7]==2 && Ground[8]==2){win=2;delay(1000);break;	}
	if(Ground[0]==2 && Ground[3]==2 && Ground[6]==2){win=2;delay(1000);break;	}
	if(Ground[1]==2 && Ground[4]==2 && Ground[7]==2){win=2;delay(1000);break;	}
	if(Ground[2]==2 && Ground[5]==2 && Ground[8]==2){win=2;delay(1000);break;	}
	if(Ground[2]==2 && Ground[4]==2 && Ground[6]==2){win=2;delay(1000);break;	}
	if(Ground[0]==2 && Ground[4]==2 && Ground[8]==2){win=2;delay(1000);break;	}

	delay(10);		
	}
	if (win==1){
p1();
delay(3000);
goto A;

	}else	if (win==2){
    readimagefile("aiwin.jpg",0,0,161,158);
	int imagefil7=imagesize(0,0,161,158);
	void *buffer7=malloc(imagefil7);
	getimage(0,0,161,158,buffer7);
cleardevice();
setbkcolor(15);
   putimage(250,300,buffer7,COPY_PUT);
delay(3000);
goto A;

	}}

		if(x_m>440 && x_m<595 && y_m>159 && y_m<304){
	
	 	setcolor(0);
	
srand(time(NULL));
	int win=-1;
	int Ground[9]={0};
	int X[1]={0};
	int player=0;
	int Cell=-1;
	int XD,YD;
	int x_m,y_m;
	
	initwindow(800,600,"2 Player DOZE",200,50);
	setbkcolor(COLOR(200,100,50));
	cleardevice();
	setcolor(0);
		
		rectangle(100,0,300,200);
		rectangle(100,200,300,400);
		rectangle(100,400,300,600);	
		rectangle(105,5,295,195);
		rectangle(105,205,295,395);
		rectangle(105,405,295,595);
		rectangle(300,0,500,200);
		rectangle(300,200,500,400);
		rectangle(300,400,500,600);
		rectangle(305,5,495,195);
		rectangle(305,205,495,395);
		rectangle(305,405,495,595);
		rectangle(500,0,700,200);
		rectangle(500,200,700,400);
		rectangle(500,400,700,600);
		rectangle(505,5,695,195);
		rectangle(505,205,695,395);
		rectangle(505,405,695,595);
		
	while(true){
		getmouseclick(WM_LBUTTONDOWN,x_m,y_m);
	if(x_m>100 && x_m<300 && y_m>0 && y_m<200){Cell=0; XD=200;YD=100;	}	
	if(x_m>100 && x_m<300 && y_m>200 && y_m<400){Cell=1; XD=200;YD=300;	}
	if(x_m>100 && x_m<300 && y_m>400 && y_m<600){Cell=2; XD=200;YD=500;	}	
	if(x_m>300 && x_m<500 && y_m>0 && y_m<200){Cell=3; XD=400;YD=100;	}	
	if(x_m>300 && x_m<500 && y_m>200 && y_m<400){Cell=4; XD=400;YD=300;	}
	if(x_m>300 && x_m<500 && y_m>400 && y_m<600){Cell=5; XD=400;YD=500;	}
	if(x_m>500 && x_m<700 && y_m>0 && y_m<200){Cell=6; XD=600;YD=100;	}	
	if(x_m>500 && x_m<700 && y_m>200 && y_m<400){Cell=7; XD=600;YD=300;	}
	if(x_m>500 && x_m<700 && y_m>400 && y_m<600){Cell=8; XD=600;YD=500;	}
	if (Cell>=0){
		
			setcolor(11);
		if(player==0 && Ground[Cell]==0){
			circle(XD,YD,80);
				circle(XD,YD,70);
			player=1;
		    Ground[Cell]=1;		
		}else
			setcolor(0);
			if(player==1 && Ground[Cell]==0){
		line(XD-70,YD-70,XD+70,YD+70);
	    line(XD+70,YD-70,XD-70,YD+70); 
			player=0;
		    Ground[Cell]=2;
	}			
	
		Cell=-1;
		}
		//player 1   +8
	if(Ground[0]==1 && Ground[1]==1 && Ground[2]==1){win=1;delay(1000);break;	}
	if(Ground[3]==1 && Ground[4]==1 && Ground[5]==1){win=1;delay(1000);break;	}
	if(Ground[6]==1 && Ground[7]==1 && Ground[8]==1){win=1;delay(1000);break;	}
	if(Ground[0]==1 && Ground[3]==1 && Ground[6]==1){win=1;delay(1000);break;	}
	if(Ground[1]==1 && Ground[4]==1 && Ground[7]==1){win=1;delay(1000);break;	}
	if(Ground[2]==1 && Ground[5]==1 && Ground[8]==1){win=1;delay(1000);break;	}
	if(Ground[2]==1 && Ground[4]==1 && Ground[6]==1){win=1;delay(1000);break;	}
	if(Ground[0]==1 && Ground[4]==1 && Ground[8]==1){win=1;delay(1000);break;	}

	//Player2  +8
	if(Ground[0]==2 && Ground[1]==2 && Ground[2]==2){win=2;delay(1000);break;	}
	if(Ground[3]==2 && Ground[4]==2 && Ground[5]==2){win=2;delay(1000);break;   	}
	if(Ground[6]==2 && Ground[7]==2 && Ground[8]==2){win=2;delay(1000);break;	}
	if(Ground[0]==2 && Ground[3]==2 && Ground[6]==2){win=2;delay(1000);break;	}
	if(Ground[1]==2 && Ground[4]==2 && Ground[7]==2){win=2;delay(1000);break;	}
	if(Ground[2]==2 && Ground[5]==2 && Ground[8]==2){win=2;delay(1000);break;	}
	if(Ground[2]==2 && Ground[4]==2 && Ground[6]==2){win=2;delay(1000);break;	}
	if(Ground[0]==2 && Ground[4]==2 && Ground[8]==2){win=2;delay(1000);break;	}

	delay(10);		
			
				
	   
	}
	

	if (win==1){
p1();
delay(3000);
goto A;

	}else	if (win==2){
p2();
delay(3000);
goto A;

	}
	delay(30);
	getch();
	closegraph();
	 
	}
	
	}		
}
